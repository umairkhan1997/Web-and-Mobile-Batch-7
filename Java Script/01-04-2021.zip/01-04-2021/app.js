// alert("Hello World")

// window.alert('Batch & Web and Mobile')


// var strVar = "Dell Pc";

// alert(468237648);

//  var intVar = 786;
//  alert(intVar);


// var names;
// names="umair";
// alert(names)




// var names;
// var name1;
// var name$two;
// var first_name;

// var 2user;
// var $user;
// var _user;


///
// var numVal = 2 + 2;
// var minVal = 2 - 4;
// var minVal = -2 - 4;
// alert(numVal);
// alert(minVal);

// var minVal = 2 * 4;
// alert(minVal);

//////MODULES OPERATOR
// var minVal = 4 % 2;
// alert(minVal);

// var minVal = 2 % 4;
// alert(minVal);


// var nums = 2;
// var numOne = -7

// var res = 5 + numOne;
// alert(res);


// var numOne = 2;
// var numTwo;
// numTwo = 6;
// var res = numOne + numTwo;
// alert(numOne + numTwo); 


// var numOne = 2;
// var numTwo;
// numTwo = 6;
// var res = numOne + numTwo;
// alert(numOne + numTwo  - 10);


// var num =1;
// alert(num++)

// var totalCost = 1 + 3 * 4;
// alert(totalCost)
// var resultOfComputation = (2 * 4) * 4 + 2;
// alert(resultOfComputation)


var numOne = "Hello";
var numTwo = 'World';
var res = numOne + " " + numTwo;
alert(res);

